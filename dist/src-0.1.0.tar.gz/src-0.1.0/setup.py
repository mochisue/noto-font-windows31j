# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.4.0,<0.5.0', 'fonttools>=4.27.1,<5.0.0']

entry_points = \
{'console_scripts': ['windows31j_noto_font = src.main:main']}

setup_kwargs = {
    'name': 'src',
    'version': '0.1.0',
    'description': 'Customize Google Fonts to the Windows-31J character set to reduce size.',
    'long_description': None,
    'author': 'mochisue',
    'author_email': 'motoki32925@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
